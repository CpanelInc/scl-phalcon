
extern zend_class_entry *phalcon_cache_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Cache_Exception);

